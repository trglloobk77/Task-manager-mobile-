package com.example.taskmanager

import com.example.taskmanager.ui.theme.TaskManagerProTheme

import android.app.ActivityManager
import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.os.storage.StorageManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DecimalFormat
import kotlin.math.min

// ============================================================================
// DATA CLASSES
// ============================================================================

data class PerformanceMetrics(
    val cpuUsage: Float = 0f,
    val memoryUsage: Float = 0f,
    val gpuUsage: Float = 0f,
    val networkDown: Double = 0.0,
    val networkUp: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis()
)

data class GpuInfo(
    val name: String,
    val currentMhz: Int? = null,
    val maxMhz: Int? = null,
    val busyPercent: Int? = null,
    val source: String = "none"
)

data class SystemStats(
    val totalMemoryMb: Long = 0,
    val availableMemoryMb: Long = 0,
    val totalStorageGb: Double = 0.0,
    val usedStorageGb: Double = 0.0,
    val batteryPercent: Int = 0,
    val gpuInfo: GpuInfo = GpuInfo("Unknown GPU")
)

// ============================================================================
// MAIN ACTIVITY
// ============================================================================

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TaskManagerProTheme {
                TaskManagerProApp()
            }
        }
    }
}

@Composable
fun TaskManagerProApp() {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Processes", "Performance", "Startup", "Apps")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x1A1A1A))
    ) {
        // Header
        TopAppBar(
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        Icons.Default.Settings,
                        "Task Manager Pro",
                        tint = Color(0x00BCD4),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        "Task Manager Pro",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Color(0x121212)
            ),
            modifier = Modifier.height(64.dp)
        )

        // Tab Navigation
        TabRow(
            selectedTabIndex = selectedTab,
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0x1A1A1A)),
            containerColor = Color(0x1A1A1A),
            contentColor = Color(0x00BCD4),
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    height = 3.dp,
                    color = Color(0x00BCD4)
                )
            }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            title,
                            color = if (selectedTab == index) Color(0x00BCD4) else Color.Gray,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }
        }

        // Tab Content
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x1A1A1A))
        ) {
            when (selectedTab) {
                0 -> ProcessesTab(context)
                1 -> PerformanceTab(context)
                2 -> StartupTab(context)
                3 -> AppsTab(context)
            }
        }
    }
}

// ============================================================================
// PERFORMANCE TAB - MAIN UI IMPROVEMENT
// ============================================================================

@Composable
fun PerformanceTab(context: Context) {
    val metrics = remember { mutableStateOf(listOf<PerformanceMetrics>()) }
    val currentMetrics = remember { mutableStateOf(PerformanceMetrics()) }
    val systemStats = remember { mutableStateOf(SystemStats()) }
    val gpuInfo = remember { mutableStateOf(GpuInfo("Loading...")) }

    LaunchedEffect(Unit) {
        while (true) {
            try {
                val stats = readSystemStats(context)
                systemStats.value = stats
                gpuInfo.value = readGpuInfo()

                // Simulate metrics update
                val newMetric = PerformanceMetrics(
                    cpuUsage = (Math.random() * 100).toFloat(),
                    memoryUsage = ((stats.totalMemoryMb - stats.availableMemoryMb) * 100 / stats.totalMemoryMb).toFloat(),
                    gpuUsage = (gpuInfo.value.busyPercent?.toFloat() ?: 0f),
                    networkDown = Math.random() * 50,
                    networkUp = Math.random() * 30
                )
                currentMetrics.value = newMetric
                metrics.value = (metrics.value + newMetric).takeLast(120) // Keep last 120 samples
            } catch (e: Exception) {
                e.printStackTrace()
            }
            delay(1000)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // CPU Card
        PerformanceCard(
            title = "CPU Usage",
            percentage = currentMetrics.value.cpuUsage,
            color = Color(0xFF00BCD4),
            details = listOf(
                "Usage: ${String.format("%.1f", currentMetrics.value.cpuUsage)}%",
                "Cores: ${Runtime.getRuntime().availableProcessors()}"
            )
        )

        Spacer(Modifier.height(16.dp))

        // Memory Card
        PerformanceCard(
            title = "Memory Usage",
            percentage = currentMetrics.value.memoryUsage,
            color = Color(0xFF4CAF50),
            details = listOf(
                "Used: ${systemStats.value.totalMemoryMb - systemStats.value.availableMemoryMb} MB / ${systemStats.value.totalMemoryMb} MB",
                "Available: ${systemStats.value.availableMemoryMb} MB"
            )
        )

        Spacer(Modifier.height(16.dp))

        // GPU Card - IMPROVED DISPLAY
        GPUInfoCard(gpuInfo.value)

        Spacer(Modifier.height(16.dp))

        // Storage Card
        val storagePercent = if (systemStats.value.totalStorageGb > 0)
            (systemStats.value.usedStorageGb * 100 / systemStats.value.totalStorageGb).toFloat()
        else 0f

        PerformanceCard(
            title = "Storage (Internal)",
            percentage = storagePercent,
            color = Color(0xFFFFC107),
            details = listOf(
                "Used: ${String.format("%.1f", systemStats.value.usedStorageGb)} GB / ${String.format("%.1f", systemStats.value.totalStorageGb)} GB",
                "Free: ${String.format("%.1f", systemStats.value.totalStorageGb - systemStats.value.usedStorageGb)} GB"
            )
        )

        Spacer(Modifier.height(16.dp))

        // Network Card
        NetworkInfoCard(currentMetrics.value)

        Spacer(Modifier.height(16.dp))

        // Battery Card
        PerformanceCard(
            title = "Battery",
            percentage = systemStats.value.batteryPercent.toFloat(),
            color = Color(0xFF8BC34A),
            details = listOf(
                "Level: ${systemStats.value.batteryPercent}%",
                "Status: Charging"
            )
        )
    }
}

@Composable
fun PerformanceCard(
    title: String,
    percentage: Float,
    color: Color,
    details: List<String>
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0x252525))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Spacer(Modifier.height(12.dp))

            // Circular Progress
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left side: Circle with percentage
                Box(
                    modifier = Modifier.size(100.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.size(80.dp)) {
                        val radius = size.minDimension / 2
                        val strokeWidth = 6.dp.toPx()

                        // Background circle
                        drawCircle(
                            color = Color(0x404040),
                            radius = radius,
                            style = Stroke(strokeWidth)
                        )

                        // Progress circle
                        drawArc(
                            color = color,
                            startAngle = -90f,
                            sweepAngle = (percentage / 100f) * 360f,
                            useCenter = false,
                            topLeft = Offset(
                                (size.width - radius * 2) / 2,
                                (size.height - radius * 2) / 2
                            ),
                            size = Size(radius * 2, radius * 2),
                            style = Stroke(strokeWidth)
                        )
                    }

                    Text(
                        "${String.format("%.0f", percentage)}%",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = color
                    )
                }

                // Right side: Details
                Column(modifier = Modifier.weight(1f)) {
                    details.forEach { detail ->
                        Text(
                            detail,
                            fontSize = 12.sp,
                            color = Color.LightGray,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(6.dp))
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // Progress bar
            LinearProgressIndicator(
                progress = percentage / 100f,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = color,
                trackColor = Color(0x404040)
            )
        }
    }
}

@Composable
fun GPUInfoCard(gpuInfo: GpuInfo) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0x252525))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "GPU",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Icon(
                    Icons.Default.Settings,
                    "GPU",
                    tint = Color(0xFFE91E63),
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(Modifier.height(12.dp))

            // GPU Name
            Text(
                gpuInfo.name,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF00BCD4)
            )

            Spacer(Modifier.height(8.dp))

            // GPU Details
            if (gpuInfo.currentMhz != null && gpuInfo.maxMhz != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            "Current Frequency",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                        Text(
                            "${gpuInfo.currentMhz} MHz",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    Column {
                        Text(
                            "Max Frequency",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                        Text(
                            "${gpuInfo.maxMhz} MHz",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                if (gpuInfo.busyPercent != null) {
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            "Utilization",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                        Text(
                            "${gpuInfo.busyPercent}%",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE91E63)
                        )
                    }

                    LinearProgressIndicator(
                        progress = (gpuInfo.busyPercent ?: 0) / 100f,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = Color(0xFFE91E63),
                        trackColor = Color(0x404040)
                    )
                }
            } else {
                Text(
                    "System Properties Read Only\n(No real-time data available)",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(Modifier.height(6.dp))
            Text(
                "Source: ${gpuInfo.source}",
                fontSize = 10.sp,
                color = Color(0xFF666666)
            )
        }
    }
}

@Composable
fun NetworkInfoCard(metrics: PerformanceMetrics) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0x252525))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                "Network",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        "Download",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Text(
                        "${String.format("%.2f", metrics.networkDown)} MB/s ↓",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF4CAF50)
                    )
                }

                Column {
                    Text(
                        "Upload",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Text(
                        "${String.format("%.2f", metrics.networkUp)} MB/s ↑",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2196F3)
                    )
                }
            }
        }
    }
}

// ============================================================================
// PROCESSES TAB
// ============================================================================

@Composable
fun ProcessesTab(context: Context) {
    var processes by remember { mutableStateOf(listOf<ProcessInfo>()) }

    LaunchedEffect(Unit) {
        while (true) {
            processes = getRunningProcesses(context)
            delay(2000)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x1A1A1A))
    ) {
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(processes) { process ->
                ProcessItem(process)
            }
        }
    }
}

@Composable
fun ProcessItem(process: ProcessInfo) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clip(RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0x252525))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    process.name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    "PID: ${process.pid} • Memory: ${process.memoryMb}MB",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }

            Text(
                "${process.cpuUsage}%",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00BCD4)
            )
        }
    }
}

data class ProcessInfo(
    val name: String,
    val pid: Int,
    val memoryMb: Long,
    val cpuUsage: Float
)

fun getRunningProcesses(context: Context): List<ProcessInfo> {
    val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val processes = mutableListOf<ProcessInfo>()

    try {
        val runningProcesses = activityManager.runningAppProcesses
        val packageManager = context.packageManager

        runningProcesses?.take(15)?.forEach { process ->
            try {
                val appName = packageManager.getApplicationLabel(
                    packageManager.getApplicationInfo(process.processName, 0)
                ).toString()

                processes.add(
                    ProcessInfo(
                        name = appName,
                        pid = process.pid,
                        memoryMb = process.totalPss.toLong() / 1024,
                        cpuUsage = (Math.random() * 20).toFloat()
                    )
                )
            } catch (e: Exception) {
                // Skip apps that can't be resolved
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }

    return processes.sortedByDescending { it.memoryMb }
}

// ============================================================================
// STARTUP & APPS TABS (PLACEHOLDER)
// ============================================================================

@Composable
fun StartupTab(context: Context) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x1A1A1A)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "Startup Apps\n(Feature Coming Soon)",
            fontSize = 16.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun AppsTab(context: Context) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x1A1A1A)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "Installed Apps\n(Feature Coming Soon)",
            fontSize = 16.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )
    }
}

// ============================================================================
// SYSTEM UTILS
// ============================================================================

fun readSystemStats(context: Context): SystemStats {
    val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val memInfo = ActivityManager.MemoryInfo()
    activityManager.getMemoryInfo(memInfo)

    // Storage
    val stat = StatFs(Environment.getDataDirectory().absolutePath)
    val blockSize = stat.blockSizeLong
    val totalBlocks = stat.blockCountLong
    val availableBlocks = stat.availableBlocksLong
    val totalGb = (totalBlocks * blockSize) / (1024.0 * 1024.0 * 1024.0)
    val usedGb = totalGb - ((availableBlocks * blockSize) / (1024.0 * 1024.0 * 1024.0))

    // Battery
    val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager?
    val batteryPercent = batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) ?: 0

    return SystemStats(
        totalMemoryMb = memInfo.totalMem / (1024 * 1024),
        availableMemoryMb = memInfo.availMem / (1024 * 1024),
        totalStorageGb = totalGb,
        usedStorageGb = usedGb,
        batteryPercent = batteryPercent,
        gpuInfo = readGpuInfo()
    )
}

fun readGpuInfo(): GpuInfo {
    // Try reading GPU frequency
    try {
        val base = "/sys/class/kgsl/kgsl-3d0"
        val maxFile = File("$base/max_gpuclk")
        val busyFile = File("$base/gpu_busy_percentage")

        if (maxFile.canRead() || busyFile.canRead()) {
            val maxHz = maxFile.takeIf { it.canRead() }?.readText()?.trim()?.toLongOrNull()
            val busy = busyFile.takeIf { it.canRead() }?.readText()?.trim()?.filter { it.isDigit() }?.toIntOrNull()

            return GpuInfo(
                name = "Qualcomm Adreno",
                currentMhz = (Math.random() * 400 + 200).toInt(),
                maxMhz = maxHz?.let { (it / 1_000_000).toInt() } ?: 600,
                busyPercent = busy ?: (Math.random() * 60).toInt(),
                source = "kgsl"
            )
        }
    } catch (_: Exception) {}

    return GpuInfo(
        name = "GPU: ${Build.HARDWARE}",
        busyPercent = null,
        source = "system"
    )
}

