package com.example.taskmanager.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkMode
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// ============================================================================
// DARK COLOR SCHEME - Professional Task Manager
// ============================================================================

private val DarkColorScheme = darkColorScheme(
    primary = CyanPrimary,                  // #00BCD4
    onPrimary = Color(0xFF000000),          // Black text on cyan
    primaryContainer = CyanSecondary,       // #00838F
    onPrimaryContainer = CyanPrimary,
    
    secondary = GPUColor,                   // #E91E63
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFF880E4F),
    onSecondaryContainer = GPUColor,
    
    tertiary = MemoryColor,                 // #4CAF50
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFF1B5E20),
    onTertiaryContainer = MemoryColor,
    
    error = ErrorColor,                     // #FF5252
    errorContainer = Color(0xFF7F0000),
    onError = Color(0xFFFFFFFF),
    onErrorContainer = ErrorColor,
    
    background = DarkBackground,            // #1A1A1A
    onBackground = TextPrimary,             // White
    
    surface = DarkSurface,                  // #252525
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,    // #353535
    onSurfaceVariant = TextSecondary,
    
    outline = BorderColor,                  // #505050
    outlineVariant = DividerColor,          // #404040
    
    scrim = Color(0xFF000000)
)

// ============================================================================
// LIGHT COLOR SCHEME (Optional for future)
// ============================================================================

private val LightColorScheme = lightColorScheme(
    primary = CyanPrimary,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFB2EBF2),
    onPrimaryContainer = Color(0xFF00363A),
    
    secondary = GPUColor,
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFD58D0),
    onSecondaryContainer = Color(0xFF3A003C),
    
    tertiary = MemoryColor,
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFF7EC699),
    onTertiaryContainer = Color(0xFF003300),
    
    error = ErrorColor,
    errorContainer = Color(0xFFFFDAD6),
    onError = Color(0xFFFFFFFF),
    onErrorContainer = Color(0xFF410002),
    
    background = LightBackground,           // #FAFAFA
    onBackground = Color(0xFF1A1A1A),
    
    surface = LightSurface,                 // #FFFFFF
    onSurface = Color(0xFF1A1A1A),
    surfaceVariant = LightSurfaceVariant,   // #F5F5F5
    onSurfaceVariant = TextTertiary,
    
    outline = Color(0xFF79747E),
    outlineVariant = Color(0xFFCAC7D0),
    
    scrim = Color(0xFF000000)
)

// ============================================================================
// TYPOGRAPHY
// ============================================================================

import androidx.compose.material3.Typography
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val TaskManagerTypography = Typography(
    displayLarge = androidx.compose.material3.Typography().displayLarge.copy(
        fontSize = 57.sp,
        lineHeight = 64.sp,
        fontWeight = FontWeight.Bold
    ),
    displayMedium = androidx.compose.material3.Typography().displayMedium.copy(
        fontSize = 45.sp,
        lineHeight = 52.sp,
        fontWeight = FontWeight.Bold
    ),
    displaySmall = androidx.compose.material3.Typography().displaySmall.copy(
        fontSize = 36.sp,
        lineHeight = 44.sp,
        fontWeight = FontWeight.Bold
    ),
    
    headlineLarge = androidx.compose.material3.Typography().headlineLarge.copy(
        fontSize = 32.sp,
        lineHeight = 40.sp,
        fontWeight = FontWeight.Bold
    ),
    headlineMedium = androidx.compose.material3.Typography().headlineMedium.copy(
        fontSize = 28.sp,
        lineHeight = 36.sp,
        fontWeight = FontWeight.SemiBold
    ),
    headlineSmall = androidx.compose.material3.Typography().headlineSmall.copy(
        fontSize = 24.sp,
        lineHeight = 32.sp,
        fontWeight = FontWeight.SemiBold
    ),
    
    titleLarge = androidx.compose.material3.Typography().titleLarge.copy(
        fontSize = 22.sp,
        lineHeight = 28.sp,
        fontWeight = FontWeight.SemiBold
    ),
    titleMedium = androidx.compose.material3.Typography().titleMedium.copy(
        fontSize = 16.sp,
        lineHeight = 24.sp,
        fontWeight = FontWeight.SemiBold
    ),
    titleSmall = androidx.compose.material3.Typography().titleSmall.copy(
        fontSize = 14.sp,
        lineHeight = 20.sp,
        fontWeight = FontWeight.Bold
    ),
    
    bodyLarge = androidx.compose.material3.Typography().bodyLarge.copy(
        fontSize = 16.sp,
        lineHeight = 24.sp,
        fontWeight = FontWeight.Normal
    ),
    bodyMedium = androidx.compose.material3.Typography().bodyMedium.copy(
        fontSize = 14.sp,
        lineHeight = 20.sp,
        fontWeight = FontWeight.Normal
    ),
    bodySmall = androidx.compose.material3.Typography().bodySmall.copy(
        fontSize = 12.sp,
        lineHeight = 16.sp,
        fontWeight = FontWeight.Normal
    ),
    
    labelLarge = androidx.compose.material3.Typography().labelLarge.copy(
        fontSize = 14.sp,
        lineHeight = 20.sp,
        fontWeight = FontWeight.SemiBold
    ),
    labelMedium = androidx.compose.material3.Typography().labelMedium.copy(
        fontSize = 12.sp,
        lineHeight = 16.sp,
        fontWeight = FontWeight.Bold
    ),
    labelSmall = androidx.compose.material3.Typography().labelSmall.copy(
        fontSize = 11.sp,
        lineHeight = 16.sp,
        fontWeight = FontWeight.Bold
    )
)

// ============================================================================
// MAIN THEME COMPOSABLE
// ============================================================================

@Composable
fun TaskManagerPCTheme(
    darkTheme: Boolean = isSystemInDarkMode(),
    // Dynamic color is available on Android 12+
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) {
                dynamicDarkColorScheme(context)
            } else {
                dynamicLightColorScheme(context)
            }
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }
    
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.primary.toArgb()
            WindowCompat.getInsetsController(window, view)?.isAppearanceLightStatusBars = darkTheme.not()
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = TaskManagerTypography,
        content = content
    )
}

// ============================================================================
// EXTENDED THEME FOR ADDITIONAL COLORS
// ============================================================================

@Composable
fun TaskManagerProTheme(
    darkTheme: Boolean = isSystemInDarkMode(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    // Uses our custom dark color scheme
    // For future: add shape and typography customization
    
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = DarkColorScheme.primary.toArgb()
            window.navigationBarColor = DarkColorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view)?.isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme,
        typography = TaskManagerTypography,
        content = content
    )
}
