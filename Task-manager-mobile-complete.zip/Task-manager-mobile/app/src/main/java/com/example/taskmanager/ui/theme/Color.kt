package com.example.taskmanager.ui.theme

import androidx.compose.ui.graphics.Color

// ============================================================================
// DARK THEME - Professional Task Manager Colors
// ============================================================================

// Backgrounds
val DarkBackground = Color(0xFF1A1A1A)      // Main background
val DarkSurface = Color(0xFF252525)         // Card background
val DarkSurfaceVariant = Color(0xFF353535)  // Pressed state

// Primary Colors
val CyanPrimary = Color(0xFF00BCD4)         // CPU, Primary accent
val CyanSecondary = Color(0xFF00838F)       // Darker cyan

// Component Colors
val CPUColor = Color(0xFF00BCD4)            // Cyan
val MemoryColor = Color(0xFF4CAF50)         // Green
val GPUColor = Color(0xFFE91E63)            // Pink/Magenta
val StorageColor = Color(0xFFFFC107)        // Amber/Yellow
val NetworkDownColor = Color(0xFF4CAF50)    // Green (download)
val NetworkUpColor = Color(0xFF2196F3)      // Blue (upload)
val BatteryColor = Color(0xFF8BC34A)        // Light green

// Text Colors
val TextPrimary = Color(0xFFFFFFFF)         // White
val TextSecondary = Color(0xFFBDBDBD)       // Light gray
val TextTertiary = Color(0xFF9E9E9E)        // Medium gray
val TextDisabled = Color(0xFF616161)        // Dark gray

// Status Colors
val SuccessColor = Color(0xFF4CAF50)        // Green
val WarningColor = Color(0xFFFFC107)        // Amber
val ErrorColor = Color(0xFFFF5252)          // Red
val InfoColor = Color(0xFF00BCD4)           // Cyan

// Divider & Borders
val DividerColor = Color(0xFF404040)        // Dark gray divider
val BorderColor = Color(0xFF505050)         // Slightly lighter border

// ============================================================================
// LIGHT THEME (Optional for future)
// ============================================================================

val LightBackground = Color(0xFFFAFAFA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF5F5F5)

// ============================================================================
// SPECIAL COLORS
// ============================================================================

// Progress indicators
val ProgressBackground = Color(0xFF404040)  // Background of progress bar
val ProgressDisabled = Color(0xFF616161)

// Hover & Focus states
val HoverOverlay = Color(0xFF333333)
val FocusOverlay = Color(0xFF404040)

// Shadows
val ShadowLight = Color(0x1A000000)
val ShadowMedium = Color(0x33000000)
val ShadowDark = Color(0x66000000)

// ============================================================================
// GRADIENT COLORS
// ============================================================================

// For future gradient backgrounds
val GradientStart = Color(0xFF1A1A1A)
val GradientEnd = Color(0xFF0D0D0D)

// Chart colors
val ChartColor1 = CyanPrimary
val ChartColor2 = MemoryColor
val ChartColor3 = GPUColor
val ChartColor4 = StorageColor
val ChartColor5 = NetworkUpColor
