# Task Manager Pro (Mobile)

Phiên bản **PRO** của Task Manager cho Android – giao diện giống Windows Task Manager, tối ưu cho điện thoại.

## Tính năng chính

- **Performance tab**: CPU, Memory, GPU (đã fix), Storage, Network, Battery
- Material Design 3 + Dark theme chuyên nghiệp
- Circular progress indicators
- Tab navigation: Processes / Performance / Startup / Apps

## Cách build

### Local (Android Studio)
1. Mở project bằng Android Studio
2. Sync Gradle
3. Run trên thiết bị / emulator

### Command line
```bash
./gradlew assembleDebug
# APK nằm tại: app/build/outputs/apk/debug/
```

## CI/CD
GitHub Actions tự động build APK khi push lên `main`.

## Package
- `com.example.taskmanager`
- minSdk 26, targetSdk 34
- Jetpack Compose + Material 3
