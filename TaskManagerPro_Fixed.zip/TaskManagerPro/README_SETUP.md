# Task Manager Pro — Setup

## ⚠️ 1 việc m PHẢI làm trước khi push (quan trọng nhất)

File `gradle/wrapper/gradle-wrapper.jar` là file **binary**, t không tải được vì môi
trường của t không có mạng. Không có file này thì `./gradlew` sẽ không chạy được.

Cách tạo nó (chọn 1 trong 2, mất ~30 giây):

**Cách 1 — Android Studio (dễ nhất):**
1. Mở thư mục `TaskManagerPro` này bằng Android Studio.
2. Android Studio tự động phát hiện thiếu wrapper và tự generate lại (hoặc
   vào `File > Sync Project with Gradle Files`).

**Cách 2 — Terminal (nếu có Gradle cài sẵn):**
```bash
cd TaskManagerPro
gradle wrapper --gradle-version 8.4
```

Sau đó check lại có file `gradle/wrapper/gradle-wrapper.jar` (vài trăm KB) là xong.

## 2. Push lên GitHub

```bash
cd TaskManagerPro
git init
git add .
git commit -m "Proper Android project structure"
git branch -M main
git remote add origin https://github.com/trglloobk77/Task-manager-mobile-.git
git push -u origin main --force
```

(Dùng `--force` nếu repo cũ đang trống/lộn xộn — cẩn thận nếu có code cũ m muốn giữ.)

## 3. Đã fix trong lần này

- ✅ Cấu trúc Gradle project chuẩn (`settings.gradle.kts`, `build.gradle.kts` root + app,
  `gradle.properties`) — đây là nguyên nhân lỗi `No file... matched to [**/*.gradle*...]`.
- ✅ `AndroidManifest.xml` + `strings.xml` + `themes.xml`.
- ✅ `MainActivity.kt`, `Color.kt`, `Theme.kt` đã copy đúng package `com.example.taskmanager`.
- ✅ `packagingOptions` → đổi thành `packaging` (API mới, hết warning deprecated).
- ✅ Workflow CI (`.github/workflows/android-build.yml`) dùng `actions/checkout@v4`,
  `actions/setup-java@v4` (JDK 17, không còn cảnh báo deprecated Node 20 / setup-java v4 cũ).
- ✅ Thêm `.gitignore` chuẩn Android để không commit `build/`, `.gradle/`, local.properties.
