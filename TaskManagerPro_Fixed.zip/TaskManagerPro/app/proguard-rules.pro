# Keep Compose runtime classes
-keep class androidx.compose.** { *; }
-dontwarn androidx.compose.**
