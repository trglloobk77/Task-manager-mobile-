# Task Manager Pro - Hướng Dẫn Cài Đặt & Cải Tiến

## 📋 Tóm Tắt Cải Tiến

### ✨ UI/UX Improvements
1. **Giao diện Material Design 3** - Modern, professional nhìn giống Windows Task Manager
2. **Dark Theme mặc định** - Màu tối (#1A1A1A) tiết kiệm pin trên OLED screen
3. **Tab Navigation** - Processes, Performance, Startup, Apps
4. **Circular Progress Indicators** - Hiển thị percentage một cách trực quan
5. **Responsive Layout** - Tối ưu cho mọi kích thước màn hình

### 🎯 Performance Tab - Main Features
1. **CPU Usage Card** - Hiển thị % CPU, số cores
2. **Memory Usage Card** - Used/Total, Available RAM
3. **GPU Info Card (FIX CHÍNH)** - Hiển thị GPU Name, Frequency, Utilization
4. **Storage Card** - Internal storage usage
5. **Network Card** - Download/Upload speed
6. **Battery Card** - Battery percentage

### 🔧 GPU Display - FIX CHI TIẾT

#### Trước (Có vấn đề)
- Text overlap / hard to read
- Không rõ ràng frequency units
- Missing utilization percentage
- Source không được giải thích

#### Sau (Fixed)
```kotlin
@Composable
fun GPUInfoCard(gpuInfo: GpuInfo) {
    // ✓ Clean card layout
    // ✓ GPU Name rõ ràng (Qualcomm Adreno, Mali, etc)
    // ✓ Current MHz vs Max MHz - side by side
    // ✓ Utilization % nếu có
    // ✓ Progress bar visual
    // ✓ Source label (kgsl, devfreq, system)
}
```

### 📊 Data Structures
```kotlin
data class PerformanceMetrics(
    val cpuUsage: Float,
    val memoryUsage: Float,
    val gpuUsage: Float,
    val networkDown: Double,
    val networkUp: Double,
    val timestamp: Long
)

data class GpuInfo(
    val name: String,
    val currentMhz: Int?,      // Real-time frequency
    val maxMhz: Int?,          // Max supported frequency
    val busyPercent: Int?,     // GPU utilization
    val source: String         // How data was obtained
)

data class SystemStats(
    val totalMemoryMb: Long,
    val availableMemoryMb: Long,
    val totalStorageGb: Double,
    val usedStorageGb: Double,
    val batteryPercent: Int,
    val gpuInfo: GpuInfo
)
```

---

## 🚀 Cách Cài Đặt

### Step 1: Copy Files
Sao chép các files sau vào project:

```
app/src/main/java/com/example/taskmanager/
├── MainActivity.kt (THAY THẾ bằng TaskManagerPro.kt)
└── ui/theme/
    ├── Color.kt (giữ nguyên)
    └── Theme.kt (giữ nguyên)

app/src/main/res/
├── values/
│   └── strings.xml

app/
└── build.gradle.kts (UPDATE)

app/src/main/
└── AndroidManifest.xml (UPDATE)
```

### Step 2: Update build.gradle.kts
Thay đổi dependencies như trong file `build_gradle_kts.txt`

### Step 3: Update AndroidManifest.xml
Sao chép permissions từ file AndroidManifest.xml

### Step 4: Compile & Run
```bash
# Gradle build
./gradlew clean build

# Chạy trên emulator hoặc device
./gradlew installDebug
```

---

## 🎨 Color Scheme (Professional)

| Component | Color | Hex |
|-----------|-------|-----|
| Background | Dark Gray | #1A1A1A |
| Cards | Darker Gray | #252525 |
| Primary | Cyan | #00BCD4 |
| CPU | Cyan | #00BCD4 |
| Memory | Green | #4CAF50 |
| GPU | Pink | #E91E63 |
| Storage | Amber | #FFC107 |
| Network Down | Green | #4CAF50 |
| Network Up | Blue | #2196F3 |
| Battery | Light Green | #8BC34A |

---

## 📈 GPU Display Fix - Detailed Changes

### Old Issue
```
GPU
GPU: 196610
━━━━━━━━━━━━━
❌ Hard to understand what "196610" means
❌ No frequency information
❌ No utilization metric
❌ Text truncated on narrow screens
```

### New Solution
```
GPU
Qualcomm Adreno
━━━━━━━━━━━━━
Current Frequency: 475 MHz
Max Frequency: 650 MHz
Utilization: 45%
[━━━━━━━━━━──────] (progress bar)
Source: kgsl
✓ Clear and professional
✓ All metrics visible
✓ Responsive layout
✓ Color-coded values
```

### GPU Reading Methods (in priority order)
1. **kgsl** (Qualcomm Adreno) - Best support
   - Path: `/sys/class/kgsl/kgsl-3d0`
   - Metrics: frequency, max_freq, busy_percentage

2. **devfreq** (Mali, MediaTek, Exynos)
   - Path: `/sys/class/devfreq/`
   - Metrics: cur_freq, max_freq

3. **System Properties** (fallback)
   - No real-time data
   - Just GPU name from hardware properties

---

## 🔄 Real-time Updates

### Performance Tab
```kotlin
LaunchedEffect(Unit) {
    while (true) {
        // Update metrics every 1 second
        val stats = readSystemStats(context)
        val gpu = readGpuInfo()
        
        // Add to history (keep last 120 samples = 2 minutes)
        metrics.value = (metrics.value + newMetric).takeLast(120)
        
        delay(1000)
    }
}
```

### Process Tab
```kotlin
LaunchedEffect(Unit) {
    while (true) {
        // Refresh every 2 seconds (less frequent to save battery)
        processes = getRunningProcesses(context)
        delay(2000)
    }
}
```

---

## 🎯 Key Features in Code

### 1. Circular Progress Indicator
```kotlin
Canvas(modifier = Modifier.size(80.dp)) {
    // Background circle (gray)
    drawCircle(color = Color(0x404040), radius = radius, ...)
    
    // Progress arc (colored)
    drawArc(color = color, 
            sweepAngle = (percentage / 100f) * 360f, ...)
}
Text("${String.format("%.0f", percentage)}%")
```

### 2. Card Layout System
Mỗi metric (CPU, GPU, Memory, etc) là một Card:
```kotlin
Card(
    modifier = Modifier.clip(RoundedCornerShape(12.dp)),
    colors = CardDefaults.cardColors(containerColor = Color(0x252525))
)
```

### 3. System Stats Reading
```kotlin
fun readSystemStats(context: Context): SystemStats {
    // ActivityManager - Memory info
    // StatFs - Storage info
    // BatteryManager - Battery percentage
    // readGpuInfo() - GPU data
}
```

### 4. GPU Info Reading
```kotlin
fun readGpuInfo(): GpuInfo {
    // Try KGSL (Qualcomm) first
    // Try devfreq (Mali/MediaTek) second
    // Fallback to System Properties
}
```

---

## 🧪 Testing GPU Display on Different Devices

### Snapdragon Devices (Qualcomm Adreno)
- ✓ Full support - freq + utilization
- Command: `adb shell cat /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage`

### MediaTek Devices (Mali GPU)
- ✓ Frequency support - no utilization
- Command: `adb shell cat /sys/class/devfreq/gpufreq/cur_freq`

### Other Devices
- ✓ Fallback to system properties
- No real-time data but GPU name shown

### Test Command
```bash
# SSH into emulator/device
adb shell

# Check GPU sysfs
cat /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage
cat /sys/class/devfreq/*/cur_freq
cat /sys/class/devfreq/*/max_freq

# Check system properties
getprop ro.hardware.egl
getprop ro.board.platform
```

---

## 🔐 Permissions Required

```xml
<!-- Access to system stats -->
<uses-permission android:name="android.permission.GET_PACKAGE_SIZE" />
<uses-permission android:name="android.permission.PACKAGE_USAGE_STATS" />

<!-- Access to network info -->
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

<!-- Access to battery info -->
<uses-permission android:name="android.permission.BATTERY_STATS" />

<!-- Access to file system stats -->
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
```

---

## 📱 UI Responsive Considerations

### Vertical Layout (Portrait)
- Full width cards
- Single column
- Scrollable content

### Horizontal Layout (Landscape)
- Cards are still full-width
- Smaller padding
- Tab height reduced

### Large Screens (Tablet)
- Sidebar navigation (future)
- Multiple columns (future)
- Larger font sizes

---

## 🐛 Troubleshooting

### GPU shows "Không đọc được GPU"
**Cause**: SELinux blocks access to sysfs
**Solution**: 
- Rooted devices: modify SELinux policy
- Fallback method works without root

### Performance metrics stuck at 0%
**Cause**: Missing permissions or API level too low
**Solution**:
- Requires Android 8.0+ (API 26+)
- Ensure PACKAGE_USAGE_STATS permission granted
- Check app-ops: `adb shell appops set com.example.taskmanager GET_APP_OPS_STATS allow`

### GPU frequency shows random numbers
**Cause**: kgsl path incorrect or device uses Mali
**Solution**:
- Check available paths: `adb shell ls -la /sys/class/kgsl/`
- Check Mali paths: `adb shell ls -la /sys/class/devfreq/`

---

## 🚀 Future Enhancements

### Phase 2
- [ ] Real charts/graphs (line chart, bar chart)
- [ ] App-specific CPU/Memory stats
- [ ] Network per-app breakdown
- [ ] Process kill functionality
- [ ] Custom refresh rates

### Phase 3
- [ ] Cloud sync of stats history
- [ ] Notifications on high usage
- [ ] Recording stats over time
- [ ] Export to CSV/JSON
- [ ] Dark/Light theme toggle

### Phase 4
- [ ] Widget for home screen
- [ ] Floating overlay mode
- [ ] System-level performance tweaks
- [ ] Battery optimization AI

---

## 📝 Version History

### v2.0-Pro (Current)
- ✨ New Material Design 3 UI
- 🔧 Fixed GPU display with proper formatting
- 📊 Real-time metrics with 1-second refresh
- 🎨 Professional color scheme
- 📱 Fully responsive layout

### v1.0 (Original)
- Basic processes view
- Basic performance monitoring
- Text-based GPU info

---

## 📞 Support & Issues

Jika gặp vấn đề:
1. Check logs: `adb logcat | grep TaskManager`
2. Clear app data: `adb shell pm clear com.example.taskmanager`
3. Rebuild: `./gradlew clean build`

---

**Happy Task Managing! 🚀**
