# 🚀 Quick Start - Task Manager Pro (5 Phút)

## Bước 1: Copy Files (2 phút)

```bash
# Vào thư mục project
cd path/to/TaskManagerPC

# Backup file cũ
cp app/src/main/java/com/example/taskmanager/MainActivity.kt \
   app/src/main/java/com/example/taskmanager/MainActivity.kt.backup

# Copy file mới
cp TaskManagerPro.kt \
   app/src/main/java/com/example/taskmanager/MainActivity.kt

# Copy theme files
cp Color.kt app/src/main/java/com/example/taskmanager/ui/theme/
cp Theme.kt app/src/main/java/com/example/taskmanager/ui/theme/
```

## Bước 2: Update build.gradle.kts (2 phút)

Mở `app/build.gradle.kts` và thay đổi:

```gradle
// Phần kotlin compose extension
composeOptions {
    kotlinCompilerExtensionVersion = "1.5.8"  // Update version này
}

// Phần dependencies
dependencies {
    // ... existing dependencies ...
    
    // Compose (update versions)
    implementation("androidx.activity:activity-compose:1.8.1")
    implementation("androidx.compose.ui:ui:1.6.1")
    implementation("androidx.compose.material3:material3:1.1.2")
    
    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
}
```

## Bước 3: Build & Run (1 phút)

```bash
# Sync Gradle
./gradlew clean build

# Chạy app
./gradlew installDebug

# Hoặc từ Android Studio:
# Build > Clean Project
# Run > Run 'app'
```

## ✅ Kiểm Tra Sau Cài Đặt

- [ ] App khởi động được
- [ ] Performance tab hiển thị
- [ ] GPU info rõ ràng
- [ ] Circular progress indicators hiển thị
- [ ] Colors match (Cyan primary, Green memory, Pink GPU)
- [ ] Không có crash

---

## 🎨 Màu Sắc Chính

| Thành phần | Màu | Hex |
|-----------|-----|-----|
| CPU | Cyan | #00BCD4 |
| Memory | Green | #4CAF50 |
| GPU | Pink | #E91E63 |
| Storage | Amber | #FFC107 |
| Battery | Light Green | #8BC34A |
| Background | Dark | #1A1A1A |

---

## 🐛 Troubleshooting

### ❌ "Cannot find symbol: TaskManagerProTheme"
**Fix**: Bạn chưa copy file Theme.kt
```bash
cp Theme.kt app/src/main/java/com/example/taskmanager/ui/theme/
```

### ❌ "GPU shows 'Loading...'"
**Fix**: Bình thường - app đang đọc GPU info. Chờ 2-3 giây.

### ❌ App vẫn còn chạy code cũ
**Fix**: Clear app cache
```bash
adb shell pm clear com.example.taskmanager
```

### ❌ Compose version conflict
**Fix**: Update compileSdk lên 34
```gradle
android {
    compileSdk = 34  // Update này
}
```

---

## 📊 Performance Tab - Các Thành Phần

```
┌─────────────────────────────────────┐
│ Task Manager Pro                    │
├─────┬────────────┬──────────────────┤
│Proc │Performance │Startup │Apps     │ ← Tabs
├─────────────────────────────────────┤
│                                     │
│ ┌──────────────────────────────┐   │
│ │ CPU Usage           [Cyan]   │   │
│ │ 45%  [Circle] Cores: 8      │   │
│ │ [════════════════════]       │   │
│ └──────────────────────────────┘   │
│                                     │
│ ┌──────────────────────────────┐   │
│ │ Memory Usage        [Green]   │   │
│ │ 50% [Circle] 2048/4096 MB    │   │
│ │ [════════════════════]        │   │
│ └──────────────────────────────┘   │
│                                     │
│ ┌──────────────────────────────┐   │
│ │ GPU             [Pink]        │   │
│ │ Qualcomm Adreno              │   │
│ │ Current: 475 MHz             │   │
│ │ Max: 650 MHz                 │   │
│ │ Util: 45% [════════]         │   │
│ └──────────────────────────────┘   │
│                                     │
│ ┌──────────────────────────────┐   │
│ │ Storage         [Amber]       │   │
│ │ 70% [Circle] 90/128 GB       │   │
│ │ [════════════════════]        │   │
│ └──────────────────────────────┘   │
│                                     │
│ ┌──────────────────────────────┐   │
│ │ Network                      │   │
│ │ Download: 2.5 MB/s ↓ [Green]│   │
│ │ Upload: 1.2 MB/s ↑ [Blue]   │   │
│ └──────────────────────────────┘   │
│                                     │
│ ┌──────────────────────────────┐   │
│ │ Battery         [LightGreen] │   │
│ │ 85% [Circle] Charging        │   │
│ │ [════════════════════]        │   │
│ └──────────────────────────────┘   │
│                                     │
└─────────────────────────────────────┘
```

---

## 🎯 Main Fixes / Improvements

### GPU Display Fix ✅
**Trước:**
```
GPU: 196610
❌ Không rõ ý nghĩa
```

**Sau:**
```
Qualcomm Adreno
Current: 475 MHz
Max: 650 MHz
Util: 45%
✅ Rõ ràng và chuyên nghiệp
```

### Circular Progress ✅
```
Old: [██████████░░░░░░░░] 50%
New:        50%
        ╱─────────╲
      ╱             ╲
     │   [CIRCLE]    │
     │    PROGRESS   │
     ╲             ╱
       ╲─────────╱
     [╌╌╌╌╌╌╌╌╌╌]
```

### Better Colors ✅
- Cyan for CPU (not generic blue)
- Pink for GPU (unique color)
- Green for Memory (health indicator)
- Professional color scheme overall

---

## 🔧 Nếu Cần Rollback

```bash
# Restore backup
cp app/src/main/java/com/example/taskmanager/MainActivity.kt.backup \
   app/src/main/java/com/example/taskmanager/MainActivity.kt

# Clean & rebuild
./gradlew clean build
./gradlew installDebug
```

---

## 📞 Support

Tham khảo các file đầy đủ:
- `INSTALLATION_GUIDE_PRO.md` - Chi tiết kỹ thuật
- `COMPARISON_OLD_VS_NEW.md` - So sánh chi tiết
- `TaskManagerPro.kt` - Source code chính
- `Color.kt`, `Theme.kt` - Theme configuration

---

**Hoàn tất! Ứng dụng sẵn sàng chạy! 🎉**

Khởi động Task Manager Pro và thưởng thức UI chuyên nghiệp! 🚀
